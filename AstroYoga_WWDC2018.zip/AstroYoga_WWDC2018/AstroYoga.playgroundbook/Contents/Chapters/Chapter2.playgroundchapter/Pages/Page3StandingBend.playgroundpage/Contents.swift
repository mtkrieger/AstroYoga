//:# Standing Forward Bend
//: Also called a _"forward fold"_ this pose relieves tension in your hamstrings and lengthens your torso.

/*:
 ## Pose Instructions:
 1. Start in **[Upward Salute](@previous)**, exhale and bend your body forward
 2. Reach for the ground and feet, exhaling and moving lower
 3. Breathe in and out, each exhale moving closer to the ground
 */

/*:
#### Extra Details
 + Official Yoga Name: **Uttanasana** (OOT-tan-AHS-ahna)
 + **ut** means _intense_ // **tan** means _stretch/extend_
 */

//: [Next Pose: Half Standing Forward Bend](@next)

//#-hidden-code
//#-code-completion(everything, hide)


import UIKit
import SceneKit
import PlaygroundSupport

var sceneView = SCNView(frame: CGRect(x: 0, y: 0, width: 375, height: 400))
var scene = SpaceScene()
sceneView.scene = scene
sceneView.backgroundColor = UIColor.black
sceneView.allowsCameraControl = true
sceneView.autoenablesDefaultLighting = true

var cameraNode = SCNNode()
cameraNode.camera = SCNCamera()
cameraNode.position = SCNVector3(x: 0, y: 1, z: 3)
scene.rootNode.addChildNode(cameraNode)

let sun = SCNSphere(radius: 0.5)
let sunNode = SCNNode(geometry: sun)
sun.firstMaterial?.selfIllumination.contents = UIImage(named: "illuminate")
sun.firstMaterial?.diffuse.contents = UIImage(named: "diffusion")

let img1 = UIImage(named: "upward_pose")!
let img2 = UIImage(named: "upward_1")!
let img3 = UIImage(named: "standing_1")!
let img4 = UIImage(named: "standing_pose")!
let animatedImage = UIImage.animatedImage(with: [img1, img2, img3, img4], duration: 3.0)
let poseImageView: UIImageView = UIImageView(image: animatedImage)
poseImageView.animationRepeatCount = 0
poseImageView.contentMode = .scaleAspectFit
poseImageView.layer.shadowColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
poseImageView.layer.shadowOpacity = 0.3
poseImageView.layer.shadowRadius = 15.0
sceneView.addSubview(poseImageView)

var label : UILabel
label = UILabel(frame: CGRect(x: 0, y: 40, width: 375, height: 60))
label.text = "Standing Forward Bend"
label.textAlignment = .center
label.font = UIFont(name: "HelveticaNeue-Light", size: 30.0)
label.textColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
sceneView.addSubview(label)

let action = SCNAction.repeatForever(SCNAction.rotate(by: .pi, around: SCNVector3(0, 1, 0), duration: 20))
sunNode.runAction(action)
scene.rootNode.addChildNode(sunNode)

//constraints
poseImageView.translatesAutoresizingMaskIntoConstraints = false
poseImageView.centerXAnchor.constraint(equalTo: sceneView.centerXAnchor).isActive = true
poseImageView.topAnchor.constraint(equalTo: sceneView.topAnchor, constant: 0).isActive = true
poseImageView.widthAnchor.constraint(equalToConstant: 425).isActive = true

label.translatesAutoresizingMaskIntoConstraints = false
label.centerXAnchor.constraint(equalTo: sceneView.centerXAnchor).isActive = true
label.topAnchor.constraint(equalTo: sceneView.topAnchor, constant: 60).isActive = true


PlaygroundPage.current.liveView = sceneView

//#-end-hidden-code
