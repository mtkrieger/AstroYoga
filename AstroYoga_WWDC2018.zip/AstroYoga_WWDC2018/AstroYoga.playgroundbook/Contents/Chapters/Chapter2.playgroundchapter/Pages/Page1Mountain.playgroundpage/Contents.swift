//: # What is a Sun Salutation?
//: The **Sun Salutation** is a flow or sequence of Yoga positions that helps improve flexibility, strength and mindfulness. It's a great way to greet a new day. Tap **"Run My Code"** and see the explorer in action!

//:# Mountain Pose
//: A foundation for this yoga sequence, the Mountain Pose centers your attention on your breath and standing tall.

/*:
 ## Pose Instructions:
 1. Stand upright with your feet shoulder width apart
 2. Stretch your arms alongside your body, palms facing out
 3. Relax your shoulders and breathe deeply
 */

/*:
 ### Extra Details
 + Official Yoga Name: **Tadasana** (tah-DAHS-anna)
 + **tada** means _mountain_ // **sana** means _pose_
 */

//: [Next Pose: Upward Salute](@next)

//#-hidden-code
//#-code-completion(everything, hide)

import UIKit
import SceneKit
import PlaygroundSupport


var sceneView = SCNView(frame: CGRect(x: 0, y: 0, width: 375, height: 400))
var scene = SpaceScene()
sceneView.scene = scene
sceneView.backgroundColor = UIColor.black
sceneView.allowsCameraControl = true
sceneView.autoenablesDefaultLighting = true

var cameraNode = SCNNode()
cameraNode.camera = SCNCamera()
cameraNode.position = SCNVector3(x: 0, y: 1, z: 3)
scene.rootNode.addChildNode(cameraNode)

let sun = SCNSphere(radius: 0.5)
let sunNode = SCNNode(geometry: sun)
sun.firstMaterial?.selfIllumination.contents = UIImage(named: "illuminate")
sun.firstMaterial?.diffuse.contents = UIImage(named: "diffusion")

let img1 = UIImage(named: "mountain_pose")!
let img2 = UIImage(named: "mountain_1")!
let animatedImage = UIImage.animatedImage(with: [img1, img2], duration: 3.0)
let poseImageView: UIImageView = UIImageView(image: animatedImage)
poseImageView.animationRepeatCount = 0
poseImageView.contentMode = .scaleAspectFit
poseImageView.layer.shadowColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
poseImageView.layer.shadowOpacity = 0.3
poseImageView.layer.shadowRadius = 15.0
sceneView.addSubview(poseImageView)

var label : UILabel
label = UILabel(frame: CGRect(x: 0, y: 40, width: 375, height: 60))
label.text = "Mountain Pose"
label.textAlignment = .center
label.font = UIFont(name: "HelveticaNeue-Light", size: 30.0)
label.textColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
sceneView.addSubview(label)

let action = SCNAction.repeatForever(SCNAction.rotate(by: .pi, around: SCNVector3(0, 1, 0), duration: 20))
sunNode.runAction(action)
scene.rootNode.addChildNode(sunNode)

//constraints
poseImageView.translatesAutoresizingMaskIntoConstraints = false
poseImageView.centerXAnchor.constraint(equalTo: sceneView.centerXAnchor).isActive = true
poseImageView.topAnchor.constraint(equalTo: sceneView.topAnchor, constant: 0).isActive = true
poseImageView.widthAnchor.constraint(equalToConstant: 425).isActive = true

label.translatesAutoresizingMaskIntoConstraints = false
label.centerXAnchor.constraint(equalTo: sceneView.centerXAnchor).isActive = true
label.topAnchor.constraint(equalTo: sceneView.topAnchor, constant: 60).isActive = true

PlaygroundPage.current.liveView = sceneView

//#-end-hidden-code
