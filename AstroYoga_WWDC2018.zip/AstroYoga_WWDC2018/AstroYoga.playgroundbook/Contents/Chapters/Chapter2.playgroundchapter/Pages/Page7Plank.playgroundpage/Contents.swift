//:# Plank Pose
//: High plank is a _swift_ way to increase strength in your upper body, psuhing through the pain gets easier over time. :-)

/*:
 ## Pose Instructions:
 1. From **[Downward Dog](@previous)** flatten your back by shifting your core towards your arms
 2. Move your shoulders directly over your wrists, making your body parallel to the floor
 3. Don't let your body sag, keep a strong core
 4. Hold this pose for a few seconds, breathing in and out
 */

/*:
### Extra Details
 + Official Yoga Name: **Plank** (It's a _plank_, c'mon)
*/

//: [Next Pose: Four-Limbed Staff Pose](@next)

//#-hidden-code
//#-code-completion(everything, hide)


import UIKit
import SceneKit
import PlaygroundSupport

var sceneView = SCNView(frame: CGRect(x: 0, y: 0, width: 375, height: 400))
var scene = SpaceScene()
sceneView.scene = scene
sceneView.backgroundColor = UIColor.black
sceneView.allowsCameraControl = true
sceneView.autoenablesDefaultLighting = true

var cameraNode = SCNNode()
cameraNode.camera = SCNCamera()
cameraNode.position = SCNVector3(x: 0, y: 1, z: 3)
scene.rootNode.addChildNode(cameraNode)

let sun = SCNSphere(radius: 0.5)
let sunNode = SCNNode(geometry: sun)
sun.firstMaterial?.selfIllumination.contents = UIImage(named: "illuminate")
sun.firstMaterial?.diffuse.contents = UIImage(named: "diffusion")

let img1 = UIImage(named: "downward_pose")!
let img2 = UIImage(named: "plank_1")!
let img3 = UIImage(named: "plank_pose")!
let animatedImage = UIImage.animatedImage(with: [img1, img2, img3], duration: 3.0)
let poseImageView: UIImageView = UIImageView(image: animatedImage)
poseImageView.animationRepeatCount = 0
poseImageView.contentMode = .scaleAspectFit
poseImageView.layer.shadowColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
poseImageView.layer.shadowOpacity = 0.3
poseImageView.layer.shadowRadius = 15.0
sceneView.addSubview(poseImageView)

var label : UILabel
label = UILabel(frame: CGRect(x: 0, y: 40, width: 375, height: 60))
label.text = "Plank"
label.textAlignment = .center
label.font = UIFont(name: "HelveticaNeue-Light", size: 30.0)
label.textColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
sceneView.addSubview(label)

let action = SCNAction.repeatForever(SCNAction.rotate(by: .pi, around: SCNVector3(0, 1, 0), duration: 20))
sunNode.runAction(action)
scene.rootNode.addChildNode(sunNode)

//constraints
poseImageView.translatesAutoresizingMaskIntoConstraints = false
poseImageView.centerXAnchor.constraint(equalTo: sceneView.centerXAnchor).isActive = true
poseImageView.topAnchor.constraint(equalTo: sceneView.topAnchor, constant: 0).isActive = true
poseImageView.widthAnchor.constraint(equalToConstant: 425).isActive = true

label.translatesAutoresizingMaskIntoConstraints = false
label.centerXAnchor.constraint(equalTo: sceneView.centerXAnchor).isActive = true
label.topAnchor.constraint(equalTo: sceneView.topAnchor, constant: 60).isActive = true


PlaygroundPage.current.liveView = sceneView

//#-end-hidden-code
