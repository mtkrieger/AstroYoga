//:# Upward-Facing Dog
//: This pose is a great way to release tension from your back and opens up your chest in some of those commonly neglected muscles.

/*:
 ## Pose Instructions:
 1. Shift your body from **[Four-Limbed Pose](@previous)** and press away from the mat until your arms straighten
 2. Let your chest open up and keep your knees off the ground
 3. Press the tops of your feet into the mat to elevate legs
 */

/*:
### Extra Details
 + Official Yoga Name: **Urdhva Mukha Svanasana** (OORD-vah MOO-kah shvon-AHS-anna)
 + **urdhva mukha** means _upward face_ // **svana** means _dog_
 */

//: [Next Pose: Finishing the Sequence](@next)

//#-hidden-code
//#-code-completion(everything, hide)


import UIKit
import SceneKit
import PlaygroundSupport

var sceneView = SCNView(frame: CGRect(x: 0, y: 0, width: 375, height: 400))
var scene = SpaceScene()
sceneView.scene = scene
sceneView.backgroundColor = UIColor.black
sceneView.allowsCameraControl = true
sceneView.autoenablesDefaultLighting = true

var cameraNode = SCNNode()
cameraNode.camera = SCNCamera()
cameraNode.position = SCNVector3(x: 0, y: 1, z: 3)
scene.rootNode.addChildNode(cameraNode)

let sun = SCNSphere(radius: 0.5)
let sunNode = SCNNode(geometry: sun)
sun.firstMaterial?.selfIllumination.contents = UIImage(named: "illuminate")
sun.firstMaterial?.diffuse.contents = UIImage(named: "diffusion")

let img1 = UIImage(named: "fourlimb_pose")!
let img2 = UIImage(named: "plank_pose")!
let img3 = UIImage(named: "upwardd_1")!
let img4 = UIImage(named: "upwardd_pose")!
let animatedImage = UIImage.animatedImage(with: [img1, img2, img3, img4], duration: 4.0)
let poseImageView: UIImageView = UIImageView(image: animatedImage)
poseImageView.animationRepeatCount = 0
poseImageView.contentMode = .scaleAspectFit
poseImageView.layer.shadowColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
poseImageView.layer.shadowOpacity = 0.3
poseImageView.layer.shadowRadius = 15.0
sceneView.addSubview(poseImageView)

var label : UILabel
label = UILabel(frame: CGRect(x: 0, y: 40, width: 375, height: 60))
label.text = "Upward Dog"
label.textAlignment = .center
label.font = UIFont(name: "HelveticaNeue-Light", size: 30.0)
label.textColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
sceneView.addSubview(label)

let action = SCNAction.repeatForever(SCNAction.rotate(by: .pi, around: SCNVector3(0, 1, 0), duration: 20))
sunNode.runAction(action)
scene.rootNode.addChildNode(sunNode)

//constraints
poseImageView.translatesAutoresizingMaskIntoConstraints = false
poseImageView.centerXAnchor.constraint(equalTo: sceneView.centerXAnchor).isActive = true
poseImageView.topAnchor.constraint(equalTo: sceneView.topAnchor, constant: 0).isActive = true
poseImageView.widthAnchor.constraint(equalToConstant: 425).isActive = true

label.translatesAutoresizingMaskIntoConstraints = false
label.centerXAnchor.constraint(equalTo: sceneView.centerXAnchor).isActive = true
label.topAnchor.constraint(equalTo: sceneView.topAnchor, constant: 60).isActive = true


PlaygroundPage.current.liveView = sceneView

//#-end-hidden-code

