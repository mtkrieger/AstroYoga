//:# Before We Begin
//: Take a few moments for yourself, clear your mind and set your **intention**. Follow the pace of the animation to calm your mind and breath. Think about one quality or virtue that you want to strive for, think patience, being "present", or strength - whatever is meaningful...to you!

//: ### Importance of Color
//: Color has psychological effects that inspire and set different types of emotions. The color palette chosen is meant to help with meditation, that doesn't mean you can't choose your own! Select from the **color pickers** below, **run the code** and make it your own.

//#-hidden-code
import PlaygroundSupport
import SpriteKit

class GameScene: SKScene {
    
    let circleOne = SKShapeNode(circleOfRadius: 50)
    let circleTwo = SKShapeNode(circleOfRadius: 50)
    let circleThree = SKShapeNode(circleOfRadius: 50)
    
    override func didMove(to view: SKView) {
        
        backgroundColor = .white
        
        addChild(circleOne)
        addChild(circleTwo)
        addChild(circleThree)
        
        circleOne.position = CGPoint(x: 280, y: 210)
        circleTwo.position = CGPoint(x: 320, y: 270)
        circleThree.position = CGPoint(x: 360, y: 210)
        //#-end-hidden-code
        circleOne.fillColor = (/*#-editable-code*/#colorLiteral(red: 0.0224100817, green: 0.7424806952, blue: 0.8699240685, alpha: 1)/*#-end-editable-code*/)
        circleTwo.fillColor = (/*#-editable-code*/#colorLiteral(red: 0.4261962175, green: 0.8096385598, blue: 0.7526146173, alpha: 1)/*#-end-editable-code*/)
        circleThree.fillColor = (/*#-editable-code*/#colorLiteral(red: 0.6054950953, green: 0.9021775126, blue: 0.8762275577, alpha: 1)/*#-end-editable-code*/)
        //#-hidden-code
        let fadeInOut = SKAction.sequence([.fadeIn(withDuration: 4.0),
                                           .fadeOut(withDuration: 5.5)])
        
        let scaleUpDown = SKAction.sequence([.scale(by: 0.1, duration: 4.5),
                                             .scale(by: 11.0, duration: 4.5)])
        
        let group = SKAction.group([fadeInOut,scaleUpDown])
        
        circleOne.run(.repeatForever(group))
        circleTwo.run(.repeatForever(group))
        circleThree.run(.repeatForever(group))
        
    }
}

let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 640, height: 480))
let scene = GameScene(size: CGSize(width: 640, height: 480))
scene.scaleMode = .aspectFill
sceneView.presentScene(scene)

PlaygroundPage.current.liveView = sceneView
//#-end-hidden-code

//: [Meet the Sun Salutation](@next)
