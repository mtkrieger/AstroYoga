import SceneKit
import UIKit

public class SpaceScene: SCNScene {
    override public init() {
        super.init()
        let stars = SCNParticleSystem(named: "StarsParticles.scnp", inDirectory: nil)!
        self.rootNode.addParticleSystem(stars)
    
    }
    
    required public init(coder aDecoder: NSCoder) {
        super.init()
    }
}
